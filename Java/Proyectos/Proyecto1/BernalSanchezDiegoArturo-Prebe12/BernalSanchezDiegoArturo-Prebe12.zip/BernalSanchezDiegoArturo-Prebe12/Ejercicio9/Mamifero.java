public class Mamifero extends Animal {
  public String toString() {
    return "estas en los mamiferos";
  }

  public String hacerRuido() {
    return "Los mamiferos hacen ruido";
  }
}
