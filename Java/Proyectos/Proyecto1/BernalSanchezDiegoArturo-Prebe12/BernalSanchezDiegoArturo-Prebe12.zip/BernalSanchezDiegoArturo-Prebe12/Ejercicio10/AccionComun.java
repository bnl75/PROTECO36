public interface AccionComun {
  public void dormir();
  public void comer();
  public void tomarAgua();
  public void respirar();
}
