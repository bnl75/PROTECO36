public class Luis implements Alumno {
  public String estudiar() {
    return "Ahora sí viene lo chido xdxd";
  }

  public String dormir() {
    return "Con 4 horas que duerma está bien...";
  }

  public String comer() {
    return "Como no tengo dinero mejor como en mi casa";
  }

  public String irALaEscuela() {
    return "Jalate pal metrobus";
  }

  public String hacerTarea() {
    return "¿Por dónde empezar?";
  }

  public String presentarExamen() {
    return "Estudié una hora antes mientras veía memes... yo creo sí paso";
  }

  public String regresarACasa() {
    return "De vuelta al metrobus :v";
  }
}
