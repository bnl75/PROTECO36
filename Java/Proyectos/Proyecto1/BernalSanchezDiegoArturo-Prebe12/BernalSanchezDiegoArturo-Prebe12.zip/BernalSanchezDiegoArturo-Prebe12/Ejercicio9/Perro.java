public class Perro extends Mamifero {
  public String hacerRuido() {
    return "GuauGuau";
  }
}
