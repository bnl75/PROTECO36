public class Diego implements Alumno {
  public String estudiar() {
    return "Voy a etudiar unas dos horas :v";
  }

  public String dormir() {
    return "Tal vez hoy sí pueda dormir :'v";
  }

  public String comer() {
    return "Estoy comiendo unos tacos";
  }

  public String irALaEscuela() {
    return "Vámonos pal metro";
  }

  public String hacerTarea() {
    return "Voy a empezar con la tarea de Proteco";
  }

  public String presentarExamen() {
    return "Ahora sí etudié prros!";
  }

  public String regresarACasa() {
    return "¿Espero el pumabús o me voy caminando?...";
  }
}
