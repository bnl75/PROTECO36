public class Animal {
  String estado = "Estoy vivo";

  public String dondeEstoy() {
    return "Este método está en la clase Animal";
  }
}
