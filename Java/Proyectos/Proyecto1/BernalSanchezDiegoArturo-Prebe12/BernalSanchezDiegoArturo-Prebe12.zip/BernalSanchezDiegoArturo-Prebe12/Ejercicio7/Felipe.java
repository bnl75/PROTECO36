public class Felipe implements Alumno {
  public String estudiar() {
    return "Ya me dio flojera estudiar";
  }

  public String dormir() {
    return "A las 11:30pm me voy a dormir";
  }

  public String comer() {
    return "Estoy comiendo en la facultad";
  }

  public String irALaEscuela() {
    return "Ojalá hoy sí llegué a tiempo :vvvvv";
  }

  public String hacerTarea() {
    return "Cuál tarea ggg";
  }

  public String presentarExamen() {
    return "Pa qué estudio si saco 3 con opción multiple :c";
  }

  public String regresarACasa() {
    return "Me voy en el pumabús porque salgo a las 10:00pm y me vayan a atorar";
  }
}
