public class Gato extends Mamifero {
  public String hacerRuido() {
    return "Grrrrrr";
  }

}
